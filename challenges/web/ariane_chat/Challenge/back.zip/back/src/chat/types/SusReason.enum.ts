export enum SusReason {
	NUDITY = 'NUDITY',
	HARASSING = 'HARASSING',
}
