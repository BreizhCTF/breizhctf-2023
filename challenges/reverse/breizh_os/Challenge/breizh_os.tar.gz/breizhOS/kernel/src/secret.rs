pub static FIND_ME: u64  = 0xdeaddeaddeaddea; // Also redacted
pub static FLAG:    &str = "REDACTED";